# NetScan — Network Port Mapper

A full-stack port scanning tool with a Flask backend and terminal-themed web UI.

## Setup & Run

```bash
# Install dependencies
pip install -r requirements.txt

# Run the app
python app.py
```

Then open http://localhost:5000 in your browser.

## Features
- TCP port scanning with concurrent threads (fast)
- Service detection (SSH, HTTP, MySQL, etc.)
- Banner grabbing
- Risk classification (LOW / MEDIUM / HIGH)
- Quick presets (Top 20, Web Ports, Full 1-1024, Extended)
- Custom port ranges: e.g. `80,443,8080` or `1-65535`

## Usage Notes
- Only scan hosts you have permission to scan
- Scans your own machine: use `127.0.0.1` or `localhost`
- Scans local network: use e.g. `192.168.1.1`
- Max 10,000 ports per scan
